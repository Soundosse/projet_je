package com.example;


import ma.app.model.Produit;
import ma.app.model.ProduitDAO;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

import java.io.IOException;
import java.math.BigDecimal;
import java.util.HashMap;
import java.util.Map;

@WebServlet("/produits")
public class ProduitServlet extends HttpServlet {

    private ProduitDAO dao;

    @Override
    public void init() {

        dao = (ProduitDAO) getServletContext()
                .getAttribute("produitDAO");

        if (dao == null) {
            throw new IllegalStateException(
                    "ProduitDAO non initialisé !");
        }
    }

    // GET : afficher la liste ou les formulaires

    @Override
    protected void doGet(HttpServletRequest req,
                         HttpServletResponse resp)
            throws ServletException, IOException {

        String action = req.getParameter("action");

        if ("new".equals(action)) {

            req.setAttribute("produit", new Produit());

            req.getRequestDispatcher(
                    "/WEB-INF/views/produits/form.jsp"
            ).forward(req, resp);

        } else if ("edit".equals(action)) {

            try {

                Long id = Long.parseLong(
                        req.getParameter("id")
                );

                Produit produit = dao.findById(id);

                if (produit == null) {
                    resp.sendError(404);
                    return;
                }

                req.setAttribute("produit", produit);

                req.getRequestDispatcher(
                        "/WEB-INF/views/produits/form.jsp"
                ).forward(req, resp);

            } catch (NumberFormatException e) {
                resp.sendError(404);
            }

        } else {

            req.setAttribute("produits", dao.findAll());

            // Message flash : affiché une seule fois

            Object flash = req.getSession().getAttribute("flash");

            if (flash != null) {
                req.setAttribute("flash", flash);
                req.getSession().removeAttribute("flash");
            }

            req.getRequestDispatcher(
                    "/WEB-INF/views/produits/list.jsp"
            ).forward(req, resp);
        }
    }

    // POST : ajouter, modifier ou supprimer

    @Override
    protected void doPost(HttpServletRequest req,
                          HttpServletResponse resp)
            throws ServletException, IOException {

        req.setCharacterEncoding("UTF-8");

        String action = req.getParameter("action");

        // SUPPRESSION

        if ("delete".equals(action)) {

            try {

                Long id = Long.parseLong(
                        req.getParameter("id")
                );

                dao.delete(id);

                req.getSession().setAttribute(
                        "flash", "Produit supprimé avec succès."
                );

                resp.sendRedirect(
                        req.getContextPath() + "/produits"
                );

            } catch (NumberFormatException e) {
                resp.sendError(400);
            }

            return;
        }

        // AJOUT OU MODIFICATION

        String idStr = req.getParameter("id");
        String nom = req.getParameter("nom");
        String description = req.getParameter("description");
        String prixStr = req.getParameter("prix");
        String stockStr = req.getParameter("stock");

        if (nom == null) nom = "";
        if (description == null) description = "";
        if (prixStr == null) prixStr = "";
        if (stockStr == null) stockStr = "";

        nom = nom.trim();

        Map<String, String> erreurs = new HashMap<>();

        // Validation du nom

        if (nom.isEmpty()) {

            erreurs.put("nom", "Le nom est obligatoire.");

        } else if (nom.length() < 2 || nom.length() > 50) {

            erreurs.put("nom",
                    "Le nom doit contenir entre 2 et 50 caractères.");
        }

        // Validation de la description

        if (description.length() > 255) {

            erreurs.put("description",
                    "Maximum 255 caractères.");
        }

        // Validation du prix

        BigDecimal prix = null;

        try {

            prix = new BigDecimal(prixStr.trim());

            if (prix.compareTo(BigDecimal.ZERO) <= 0) {

                erreurs.put("prix",
                        "Le prix doit être strictement positif.");
            }

        } catch (NumberFormatException e) {

            erreurs.put("prix",
                    "Veuillez saisir un prix valide.");
        }

        // Validation du stock

        int stock = 0;

        if (!stockStr.trim().isEmpty()) {

            try {

                stock = Integer.parseInt(stockStr.trim());

                if (stock < 0) {
                    erreurs.put("stock",
                            "Le stock doit être supérieur ou égal à 0.");
                }

            } catch (NumberFormatException e) {

                erreurs.put("stock",
                        "Le stock doit être un entier valide.");
            }
        }

        // Vérification de l'identifiant

        Long id = null;

        if (idStr != null && !idStr.trim().isEmpty()) {

            try {

                id = Long.parseLong(idStr);

                if (dao.findById(id) == null) {
                    resp.sendError(404);
                    return;
                }

            } catch (NumberFormatException e) {
                resp.sendError(400);
                return;
            }
        }

        // Créer l'objet même en cas d'erreur
        // pour conserver les valeurs saisies

        Produit produit = new Produit(
                id, nom, description, prix, stock
        );

        if (!erreurs.isEmpty()) {

            req.setAttribute("erreurs", erreurs);
            req.setAttribute("produit", produit);

            req.getRequestDispatcher(
                    "/WEB-INF/views/produits/form.jsp"
            ).forward(req, resp);

            return;
        }

        // Enregistrement

        dao.save(produit);

        String message;

        if (id == null) {
            message = "Produit " + nom + " ajouté avec succès.";
        } else {
            message = "Produit " + nom + " modifié avec succès.";
        }

        req.getSession().setAttribute("flash", message);

        resp.sendRedirect(
                req.getContextPath() + "/produits"
        );
    }
}