package com.example.model;

import ma.app.model.Produit;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.atomic.AtomicLong;

public class ProduitDAO {

    private final Map<Long, ma.app.model.Produit> produits =
            new ConcurrentHashMap<>();

    private final AtomicLong sequence =
            new AtomicLong(0);

    public ProduitDAO() {

        save(new ma.app.model.Produit(null,
                "Laptop",
                "Dell XPS 13",
                new BigDecimal("9500.00"),
                5));

        save(new ma.app.model.Produit(null,
                "Souris",
                "Logitech MX Master",
                new BigDecimal("650.00"),
                20));
    }

    public List<ma.app.model.Produit> findAll() {

        List<ma.app.model.Produit> liste =
                new ArrayList<>(produits.values());

        liste.sort(Comparator.comparing(ma.app.model.Produit::getId));

        return liste;
    }

    public ma.app.model.Produit findById(Long id) {
        return produits.get(id);
    }

    public void save(Produit p) {

        if (p.getId() == null) {
            p.setId(sequence.incrementAndGet());
        }

        produits.put(p.getId(), p);
    }

    public void delete(Long id) {
        produits.remove(id);
    }
}