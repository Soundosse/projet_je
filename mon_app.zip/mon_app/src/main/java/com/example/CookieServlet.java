
package com.example;

import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.Cookie;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

import java.io.IOException;

@WebServlet("/cookies")
public class CookieServlet extends HttpServlet {

    @Override
    protected void doGet(HttpServletRequest req,
                         HttpServletResponse resp)
            throws IOException {

        resp.setContentType("text/html;charset=UTF-8");

        String action = req.getParameter("action");

        // Créer un cookie
        if ("set".equals(action)) {

            Cookie cookie = new Cookie("theme", "dark");

            // Durée : 30 jours
            cookie.setMaxAge(30 * 24 * 60 * 60);

            // Chemin du cookie
            cookie.setPath("/");

            resp.addCookie(cookie);
        }

        // Afficher les cookies
        var out = resp.getWriter();

        out.println("<html>");
        out.println("<head><title>Gestion des cookies</title></head>");
        out.println("<body>");

        out.println("<h1>Gestion des cookies</h1>");

        out.println("<a href='cookies?action=set'>");
        out.println("<button>Créer le cookie theme</button>");
        out.println("</a>");

        out.println("<h2>Liste des cookies :</h2>");

        Cookie[] cookies = req.getCookies();

        if (cookies != null && cookies.length > 0) {

            for (Cookie c : cookies) {
                out.println("<p>" + c.getName()
                        + " : " + c.getValue() + "</p>");
            }

        } else {
            out.println("<p>Aucun cookie trouvé.</p>");
        }

        out.println("</body>");
        out.println("</html>");
    }
}
