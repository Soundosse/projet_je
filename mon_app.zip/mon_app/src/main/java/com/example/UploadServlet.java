
package com.example;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.MultipartConfig;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.Part;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;

@WebServlet("/upload")
@MultipartConfig
public class UploadServlet extends HttpServlet {

    @Override
    protected void doPost(HttpServletRequest req,
                          HttpServletResponse resp)
            throws ServletException, IOException {

        // Recuperer le fichier
        Part filePart = req.getPart("file");

        // Recuperer son nom
        String fileName = Path.of(
                filePart.getSubmittedFileName()
        ).getFileName().toString();

        // Verifier que le fichier n'est pas vide
        if (fileName.isBlank() || filePart.getSize() == 0) {
            resp.sendError(
                    HttpServletResponse.SC_BAD_REQUEST,
                    "Veuillez choisir un fichier."
            );
            return;
        }

        // Creer le dossier uploads dans l'application
        String uploadPath = getServletContext()
                .getRealPath("/uploads");

        Path uploadDir = Path.of(uploadPath);

        Files.createDirectories(uploadDir);

        // Enregistrer le fichier
        Path destination = uploadDir.resolve(fileName);

        try (var input = filePart.getInputStream()) {
            Files.copy(input, destination);
        }

        // Afficher le resultat
        resp.setContentType("text/html;charset=UTF-8");

        resp.getWriter().println(
                "<h1>Fichier uploadé avec succès !</h1>"
        );

        resp.getWriter().println(
                "<p>Nom du fichier : " + fileName + "</p>"
        );
    }
}
