<%@ page contentType="text/html;charset=UTF-8" %>
<%@ taglib prefix="c" uri="jakarta.tags.core" %>
<%@ taglib prefix="fmt" uri="jakarta.tags.fmt" %>

<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <title>Catalogue de produits</title>
</head>
<body>

<h1>Catalogue de produits</h1>

<c:if test="${not empty flash}">
    <p style="color:green">
        <c:out value="${flash}"/>
    </p>
</c:if>

<p>
    <a href="${pageContext.request.contextPath}/produits?action=new">
        Ajouter un produit
    </a>
</p>

<c:choose>

    <c:when test="${empty produits}">

        <p>Aucun produit.</p>

    </c:when>

    <c:otherwise>

        <table border="1" cellpadding="10">

            <thead>
            <tr>
                <th>Nom</th>
                <th>Description</th>
                <th>Prix</th>
                <th>Stock</th>
                <th>Actions</th>
            </tr>
            </thead>

            <tbody>

            <c:forEach var="p" items="${produits}">

                <tr>

                    <td>
                        <c:out value="${p.nom}"/>
                    </td>

                    <td>
                        <c:out value="${p.description}"/>
                    </td>

                    <td>
                        <fmt:formatNumber
                            value="${p.prix}"
                            minFractionDigits="2"
                            maxFractionDigits="2"/>
                    </td>

                    <td>

                        <c:choose>

                            <c:when test="${p.stock == 0}">
                                <span style="color:red">0</span>
                            </c:when>

                            <c:otherwise>
                                <c:out value="${p.stock}"/>
                            </c:otherwise>

                        </c:choose>

                    </td>

                    <td>

                        <a href="${pageContext.request.contextPath}/produits?action=edit&id=${p.id}">
                            Éditer
                        </a>

                        <form method="post"
                              action="${pageContext.request.contextPath}/produits"
                              onsubmit="return confirm('Voulez-vous vraiment supprimer ce produit ?');">

                            <input type="hidden"
                                   name="action"
                                   value="delete">

                            <input type="hidden"
                                   name="id"
                                   value="${p.id}">

                            <button type="submit">
                                Supprimer
                            </button>

                        </form>

                    </td>

                </tr>

            </c:forEach>

            </tbody>

        </table>

    </c:otherwise>

</c:choose>

<br>

<a href="${pageContext.request.contextPath}/dashboard">
    Retour au tableau de bord
</a>

</body>
</html>